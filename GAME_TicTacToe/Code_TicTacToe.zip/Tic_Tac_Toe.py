from tkinter import *
import tkinter.messagebox as tmsg
import random
import os

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

root = Tk()
root.geometry("400x400")
root.title("Tic Tac Toe")
root.wm_iconbitmap(resource_path('Tic_Tac_Toe_Icon.ico'))
root.resizable(0,0)

First_Player = ""
Second_Player = ""
Current_Player = ""
First_Player_Char = ""
Second_Player_Char = ""
First_Player_Turn = "OFF"
Second_Player_Turn = "OFF"
Game_Status = "OVER"
Number_Of_Turn = 0
First_Player_allocation = list()
Second_Player_allocation = list()
button_list = []

def Clear(root):
    widget_list = root.grid_slaves()
    for widget in widget_list:
        widget.destroy()

def Home_Page(root):
    Clear(root)

    Frame_1 = Frame()
    Frame_1.grid(row=0, column=0)
    Label(Frame_1, text="Tic Tac Toe", fg="red", padx=100, pady=25, font="Verdana 20 bold").grid()
    Frame_3 = Frame()
    Frame_3.grid(row=1, column=0)
    Button(Frame_3, text="vs Computer", padx=20, bg="cyan", font="Verdana 10 bold", command=lambda: askUserName_Page(root, "WithComputer")).grid(row=0, column=0, padx=30)
    Button(Frame_3, text="vs Human", padx=20, bg="cyan", font="Verdana 10 bold", command=lambda: askUserName_Page(root, "WithHuman")).grid(row=0, column=1, padx=30)

def askUserName_Page(root, opponent):
    Clear(root)

    Frame_1 = Frame()
    Frame_1.grid(row=0, column=0)
    Label(Frame_1,text="Enter Name", padx=120, pady=25, font="Verdana 20 bold", fg="red").grid(row=0, column=0)

    Frame_3 = Frame()
    Frame_3.grid(row=1, column=0)
    if opponent == "WithHuman":
        Label(Frame_3, text="First Player", padx=5, pady=2, font="Verdana 10 bold").grid(row=0, column=0)
    else:
        Label(Frame_3, text="Player", padx=5, pady=2, font="Verdana 10 bold").grid(row=0, column=0)
    FirstPlayerValue = StringVar()
    Entry(Frame_3, width=30, textvariable=FirstPlayerValue).grid(row=0, column=1)
    Label(Frame_3, text="First 10 characters are acceptable", fg="red", padx=15, pady=2).grid(row=1, column=1)

    if opponent == "WithHuman":
        Label(Frame_3, text="Second Player", padx=5, pady=2, font="Verdana 10 bold").grid(row=2, column=0)
        SecondPlayerValue = StringVar()
        Entry(Frame_3, width=30, textvariable=SecondPlayerValue).grid(row=2, column=1)
        Label(Frame_3, text="First 10 characters are acceptable", fg="red", padx=15, pady=2).grid(row=3, column=1)

    Frame_3 = Frame()
    Frame_3.grid(row=2, column=0)
    if opponent == "WithHuman":
        Button(Frame_3, text="Start Game", padx=15, pady=10, bg="cyan", font="Verdana 10 bold", command= lambda : ValidateName(root, FirstPlayerValue.get(), SecondPlayerValue.get(), "WithHuman")).grid(row=2, column=0, pady=10)
    else:
        Button(Frame_3, text="Start Game", padx=15, pady=10, bg="cyan", font="Verdana 10 bold", command=lambda: ValidateName(root, FirstPlayerValue.get(), "Computer", "WithComputer")).grid(row=2, column=0, pady=10)

def ValidateName(root, Player_1, Player_2, mode):
    Player_1 = Player_1.strip()
    Player_2 = Player_2.strip()

    if Player_1 == "" or Player_2 == "":
        tmsg.showinfo("", "Please Enter a Valid Player Name")
        return

    if mode == "WithHuman":
        if Player_1.lower() == "computer" or Player_2.lower() == "computer":
            tmsg.showinfo("", "Player Name can't be \"Computer\"")
            return
    else:
        if Player_1.lower() == "computer":
            tmsg.showinfo("", "Player Name can't be \"Computer\"")
            return

    if len(Player_1) > 10:
        Player_1 = Player_1[0:10]
    if len(Player_2) > 10:
        Player_2 = Player_2[0:10]

    draw_game_board(root, Player_1, Player_2)

def draw_game_board(root, Player_1, Player_2):
    Clear(root)

    global First_Player
    global Second_Player
    global First_Player_Char
    global Second_Player_Char
    global Game_Status
    global First_Player_Turn
    global Number_Of_Turn
    global First_Player_allocation
    global Second_Player_allocation
    global Current_Player

    Frame_1 = Frame()
    Frame_1.grid(row=0, column=0)
    Frame_2 = Frame()
    Frame_2.grid(row=1, column=0, pady=5)
    Frame_3 = Frame()
    Frame_3.grid(row=2, column=0, pady=5)
    Frame_4 = Frame()
    Frame_4.grid(row=3, column=0, pady=5)

    First_Player = random.choice([Player_1, Player_2])
    Current_Player = First_Player
    Second_Player = str((set((Player_1, Player_2)).difference(set((First_Player,)))).pop())
    First_Player_Char = 'X'
    Second_Player_Char = 'O'

    Game_Status = "IN_PROGRESS"
    First_Player_Turn = "ON"
    Number_Of_Turn = 0
    First_Player_allocation = [False]*9
    Second_Player_allocation = [False]*9

    Label(Frame_1, text=f"                               ").grid(column=0, row=0)
    Label(Frame_1, text=f"{First_Player} : {First_Player_Char}", padx=10, pady=5, font="Verdana 10 bold").grid(row=0, column=1)
    Label(Frame_1, text=f"{Second_Player} : {Second_Player_Char}", padx=10, pady=5, font="Verdana 10 bold").grid(row=1, column=1)

    Label(Frame_2, text=f"                               ").grid(column=0, row=0)
    label = Label(Frame_2, text=f"{First_Player}'s turn", bg="cyan", padx=10, pady=5, font="Verdana 10 bold")
    label.grid(row=0, column=1,padx=20)
    Tic_Tac_Toe_pad(Frame_2,Frame_3,Frame_4, label)
    if First_Player == "Computer":
        Number_Of_Turn += 1
        computer_Movement("X", "First_Player", label)

def Tic_Tac_Toe_pad(Frame_2, Frame_3,Frame_4,label):
    global button_list
    Label(Frame_3, text=f"                               ").grid(column=0, row=0)
    btn1 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn1, 1, Frame_2, Frame_4, label))
    btn1.grid(column=1, row=0)
    btn2 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn2, 2, Frame_2, Frame_4, label))
    btn2.grid(column=2, row=0)
    btn3 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn3, 3, Frame_2, Frame_4, label))
    btn3.grid(column=3, row=0)
    btn4 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn4, 4, Frame_2, Frame_4, label))
    btn4.grid(column=1, row=1)
    btn5 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn5, 5, Frame_2, Frame_4, label))
    btn5.grid(column=2, row=1)
    btn6 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn6, 6, Frame_2, Frame_4, label))
    btn6.grid(column=3, row=1)
    btn7 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn7, 7, Frame_2, Frame_4, label))
    btn7.grid(column=1, row=2)
    btn8 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn8, 8, Frame_2, Frame_4, label))
    btn8.grid(column=2, row=2)
    btn9 = Button(Frame_3, text=" ", bg="yellow", fg="Black", width=3, height=1, font=('Helvetica', '20'), command=lambda: clicked(btn9, 9, Frame_2, Frame_4, label))
    btn9.grid(column=3, row=2)

    button_list = [btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9]

def clicked(button,button_pos,Frame_2,Frame_4,label):
    global First_Player_Turn
    global Second_Player_Turn
    global First_Player
    global Second_Player
    global Game_Status
    global Number_Of_Turn
    global First_Player_allocation
    global Second_Player_allocation
    global Current_Player
    global button_list

    if Game_Status != "OVER" and Number_Of_Turn <= 9:
        if button["text"] == " ":
            if First_Player_Turn == "ON":
                if First_Player != "Computer":
                    Number_Of_Turn += 1
                    button["text"] = "X"
                    First_Player_allocation[button_pos-1] = True
                    First_Player_Turn = "OFF"
                    Second_Player_Turn = "ON"
                    label["text"] = f"{Second_Player}'s turn"
                    if Number_Of_Turn >= 5:
                        if check_if_player_won(First_Player_allocation):
                            finish_game(label, Frame_2, Frame_4, First_Player)
                if Second_Player == "Computer" and Number_Of_Turn < 9:
                    Number_Of_Turn += 1
                    computer_Movement("O","Second_Player",label)
                    if Number_Of_Turn >= 5:
                        if check_if_player_won(Second_Player_allocation):
                            finish_game(label, Frame_2, Frame_4, Second_Player)
            else:
                if Second_Player != "Computer":
                    Number_Of_Turn += 1
                    button["text"] = "O"
                    Second_Player_allocation[button_pos-1] = True
                    First_Player_Turn = "ON"
                    Second_Player_Turn = "OFF"
                    label["text"] = f"{First_Player}'s turn"
                    if Number_Of_Turn >= 5:
                        if check_if_player_won(Second_Player_allocation):
                            finish_game(label, Frame_2, Frame_4, Second_Player)
                if First_Player == "Computer" and Number_Of_Turn < 9:
                    Number_Of_Turn += 1
                    computer_Movement("X","First_Player",label)
                    if Number_Of_Turn >= 5:
                        if check_if_player_won(First_Player_allocation):
                            finish_game(label, Frame_2, Frame_4, First_Player)

    if Game_Status == "IN_PROGRESS" and Number_Of_Turn == 9:
        label["text"] = "Sorry !!!"
        Label(Frame_2, text=f"Nobody won", fg="red", padx=10, pady=5, font="Verdana 15 bold").grid(row=1, column=1)
        Label(Frame_4, text=f"                               ").grid(column=0, row=0)
        Button(Frame_4, text="Play Again", padx=15, pady=5, bg="cyan", font="Verdana 10 bold",command=lambda: Home_Page(root)).grid(row=0, column=1, pady=5)

def computer_Movement(player_char, player, label):
    global First_Player_allocation
    global Second_Player_allocation
    global button_list
    global First_Player_Turn
    global Second_Player_Turn
    global First_Player
    global Second_Player

    blank_position = check_blank_position(First_Player_allocation, Second_Player_allocation)
    if player == "First_Player":
        computer_pos = computer_move(blank_position, Second_Player_allocation, First_Player_allocation)
    else:
        computer_pos = computer_move(blank_position, First_Player_allocation, Second_Player_allocation)
    button_list[computer_pos]["text"] = player_char
    if player == "First_Player":
        First_Player_allocation[computer_pos] = True
        First_Player_Turn = "OFF"
        Second_Player_Turn = "ON"
        label["text"] = f"{Second_Player}'s turn"
    else:
        Second_Player_allocation[computer_pos] = True
        First_Player_Turn = "ON"
        Second_Player_Turn = "OFF"
        label["text"] = f"{First_Player}'s turn"

def computer_move(blank_position, Player_allocation, Own_allocation):
    for index in blank_position:
        dummy_allocation = Own_allocation[:]
        dummy_allocation[index] = True
        if dummy_allocation[0] and dummy_allocation[1] and dummy_allocation[2]:
            return index
        elif dummy_allocation[3] and dummy_allocation[4] and dummy_allocation[5]:
            return index
        elif dummy_allocation[6] and dummy_allocation[7] and dummy_allocation[8]:
            return index
        elif dummy_allocation[0] and dummy_allocation[3] and dummy_allocation[6]:
            return index
        elif dummy_allocation[1] and dummy_allocation[4] and dummy_allocation[7]:
            return index
        elif dummy_allocation[2] and dummy_allocation[5] and dummy_allocation[8]:
            return index
        elif dummy_allocation[0] and dummy_allocation[4] and dummy_allocation[8]:
            return index
        elif dummy_allocation[2] and dummy_allocation[4] and dummy_allocation[6]:
            return index
        else:
            pass

    for index in blank_position:
        dummy_allocation = Player_allocation[:]
        dummy_allocation[index] = True
        if dummy_allocation[0] and dummy_allocation[1] and dummy_allocation[2]:
            return index
        elif dummy_allocation[3] and dummy_allocation[4] and dummy_allocation[5]:
            return index
        elif dummy_allocation[6] and dummy_allocation[7] and dummy_allocation[8]:
            return index
        elif dummy_allocation[0] and dummy_allocation[3] and dummy_allocation[6]:
            return index
        elif dummy_allocation[1] and dummy_allocation[4] and dummy_allocation[7]:
            return index
        elif dummy_allocation[2] and dummy_allocation[5] and dummy_allocation[8]:
            return index
        elif dummy_allocation[0] and dummy_allocation[4] and dummy_allocation[8]:
            return index
        elif dummy_allocation[2] and dummy_allocation[4] and dummy_allocation[6]:
            return index
        else:
            pass

    dummy_allocation = []
    for index in [0,2,6,8]:
        if index in blank_position:
            dummy_allocation.append(index)
    if len(dummy_allocation) > 0:
        return random.choice(dummy_allocation)

    if 4 in blank_position:
        return 4

    dummy_allocation = []
    for index in [1, 3, 5, 7]:
        if index in blank_position:
            dummy_allocation.append(index)
    if len(dummy_allocation) > 0:
        return random.choice(dummy_allocation)

def check_blank_position(First_Player_allocation, Second_Player_allocation):
    blank_position = list()
    for i, value in enumerate(First_Player_allocation):
        if not(First_Player_allocation[i] or Second_Player_allocation[i]):
            blank_position.append(i)
    return blank_position

def finish_game(label, Frame_2, Frame_4, Player):
    global Game_Status

    Game_Status = "OVER"
    label["text"] = "Congratulation !!!"
    Label(Frame_2, text=f"{Player} won", fg="red", padx=10, pady=5, font="Verdana 15 bold").grid(row=1, column=1)

    Label(Frame_4, text=f"                               ").grid(column=0, row=0)
    Button(Frame_4, text="Play Again", padx=15, pady=5, bg="cyan", font="Verdana 10 bold",command=lambda: Home_Page(root)).grid(row=0, column=1, pady=5)

def check_if_player_won(allocation):
    if allocation[0] and allocation[1] and allocation[2]:
        return True
    elif allocation[3] and allocation[4] and allocation[5]:
        return True
    elif allocation[6] and allocation[7] and allocation[8]:
        return True
    elif allocation[0] and allocation[3] and allocation[6]:
        return True
    elif allocation[1] and allocation[4] and allocation[7]:
        return True
    elif allocation[2] and allocation[5] and allocation[8]:
        return True
    elif allocation[0] and allocation[4] and allocation[8]:
        return True
    elif allocation[2] and allocation[4] and allocation[6]:
        return True
    else:
        return False

Home_Page(root)

root.mainloop()